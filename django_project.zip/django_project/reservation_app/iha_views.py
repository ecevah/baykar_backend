from django.shortcuts import get_object_or_404
from rest_framework import status, viewsets
from rest_framework.response import Response
from rest_framework.decorators import action
from .models import IHA
from .iha_serializer import IHASerializer

class IHAViewSet(viewsets.ViewSet):
    @action(methods=['POST'], detail=False)
    def create(self, request):
        serializer = IHASerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(methods=['GET'], detail=False)
    def list(self, request):
        queryset = IHA.objects.all()
        serializer = IHASerializer(queryset, many=True)
        return Response(serializer.data)

    @action(methods=['GET'], detail=True)
    def retrieve(self, request, pk=None):
        queryset = IHA.objects.all()
        iha = get_object_or_404(queryset, pk=pk)
        serializer = IHASerializer(iha)
        return Response(serializer.data)

    @action(methods=['DELETE'], detail=True)
    def destroy(self, request, pk=None):
        queryset = IHA.objects.all()
        iha = get_object_or_404(queryset, pk=pk)
        iha.delete()
        return Response({'status': True, 'message': f'IHA Deleted. ID={pk}'}, status=status.HTTP_204_NO_CONTENT)

    @action(methods=['PUT'], detail=True)
    def update(self, request, pk=None):
        queryset = IHA.objects.all()
        iha = get_object_or_404(queryset, pk=pk)
        serializer = IHASerializer(iha, data=request.data, partial=True)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        updated_data = serializer.data
        updated_data['message'] = 'IHA updated successfully.'
        return Response(updated_data, status=status.HTTP_200_OK)